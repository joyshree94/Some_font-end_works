(function(){
  var fusoionad_script = document.createElement('script');
  fusoionad_script.type = 'text/javascript';
  fusoionad_script.async = true;
  fusoionad_script.id = "_fusionads_js";
  fusoionad_script.src = '//cdn.fusionads.net/fusion.js?zoneid=1332&serve=C6SDP2Y&placement=callmenickcom';
  document.body.appendChild(fusoionad_script);
})();