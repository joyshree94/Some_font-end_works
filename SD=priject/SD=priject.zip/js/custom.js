

$(".btn1").eq( 0 ).click(function(){
	for(i = 0; i < $(".btn1").length; i++) {
    	if($(".btn1").eq( i ).hasClass("active")){
    	$(".btn1").eq( i ).removeClass("active");
		};
        if($("#tab-part .part").eq( i ).hasClass("active")){
    	$("#tab-part .part").eq( i ).removeClass("active");
		};
	}
	  $(".btn1").eq( 0 ).addClass("active");
	  $("#tab-part .part").eq( 0 ).addClass("active");
}); 
$(".btn1").eq( 1 ).click(function(){
	for(i = 0; i < $(".btn1").length; i++) {
    	if($(".btn1").eq( i ).hasClass("active")){
    	$(".btn1").eq( i ).removeClass("active");
		};
		if($("#tab-part .part").eq( i ).hasClass("active")){
    	$("#tab-part .part").eq( i ).removeClass("active");
		};
  
	}
	  $(".btn1").eq( 1 ).addClass("active");
	  $("#tab-part .part").eq( 1 ).addClass("active");
}); 
$(".btn1").eq( 2 ).click(function(){
	for(i = 0; i < $(".btn1").length; i++) {
    	if($(".btn1").eq( i ).hasClass("active")){
    	$(".btn1").eq( i ).removeClass("active");
		};
		if($("#tab-part .part").eq( i ).hasClass("active")){
    	$("#tab-part .part").eq( i ).removeClass("active");
		};
  
	}
	  $(".btn1").eq( 2 ).addClass("active");
	  $("#tab-part .part").eq( 2 ).addClass("active");
}); 
$(".btn1").eq( 3 ).click(function(){
	for(i = 0; i < $(".btn1").length; i++) {
    	if($(".btn1").eq( i ).hasClass("active")){
    	$(".btn1").eq( i ).removeClass("active");
		};
		if($("#tab-part .part").eq( i ).hasClass("active")){
    	$("#tab-part .part").eq( i ).removeClass("active");
		};
  
	}
	  $(".btn1").eq( 3 ).addClass("active");
	  $("#tab-part .part").eq( 3 ).addClass("active");
}); 
$(".btn1").eq( 4 ).click(function(){
	for(i = 0; i < $(".btn1").length; i++) {
    	if($(".btn1").eq( i ).hasClass("active")){
    	$(".btn1").eq( i ).removeClass("active");
		};
		if($("#tab-part .part").eq( i ).hasClass("active")){
    	$("#tab-part .part").eq( i ).removeClass("active");
		};
  
	}
	  $(".btn1").eq( 4 ).addClass("active");
	  $("#tab-part .part").eq( 4 ).addClass("active");
}); 